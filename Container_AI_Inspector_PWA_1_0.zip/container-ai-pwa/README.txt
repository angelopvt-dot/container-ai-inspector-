CONTAINER AI INSPECTOR 1.0 - PWA DEMO

Incluye: cámara mediante selector nativo, registro e historial en IndexedDB, exportación JSON, biblioteca introductoria, pantalla de consulta IA no conectada, service worker offline.

PUBLICAR SIN GITHUB: Utiliza un alojamiento estático HTTPS que acepte subir una carpeta o ZIP y conserve los archivos en la raíz del sitio. Ejemplo: Netlify Drop (https://app.netlify.com/drop). En Chrome Android, activar 'Sitio para computadoras' si es necesario, descomprimir el ZIP, subir la carpeta completa (si el sitio lo admite) o usar otro host que acepte ZIP. Netlify Drop puede exigir selección de carpeta y no siempre funciona en Chrome Android. No se garantiza que este método funcione desde todos los móviles.

Una vez publicado, abrir URL HTTPS en Chrome > menú > Instalar aplicación / Añadir a pantalla principal. Para funcionar offline, visitar primero el sitio con internet.

AVISOS: No hay detección IA, análisis de daños ni códigos IICL automáticos. No incluye manuales IICL con copyright. No usar como criterio de aceptación/reparación. Los datos se guardan solo en el navegador local y pueden borrarse con datos del sitio. No es APK.
